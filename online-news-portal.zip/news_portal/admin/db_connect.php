<?php 

$conn= new mysqli('localhost','root','','news_portal_db')or die("Could not connect to mysql".mysqli_error($con));
