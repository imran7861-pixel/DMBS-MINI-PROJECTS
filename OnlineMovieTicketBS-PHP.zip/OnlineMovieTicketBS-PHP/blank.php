<?php include('header.php');?>
</div>
<div class="content">
	<div class="wrap">
		<div class="content-top">
			<h3>Movies</h3>
			xvc
			</div>
			
		<div class="clear"></div>	
		
	</div>
<?php include('footer.php');?>
</div>